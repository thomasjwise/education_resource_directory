##### Introduction

## Install Packages 
install.packages("tidyverse")
install.packages("RColorBrewer")
install.packages("ghibli")
install.packages("palettetown")

## Load Packages 
library(tidyverse)
library(RColorBrewer)
library(ghibli)
library(palettetown)