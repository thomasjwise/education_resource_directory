## Install Packages
install.packages("tidyverse")
install.packages("caret")
install.packages("tree")
install.packages("rpart")
install.packages("rpart.plot")
install.packages("e1071")

## Load Packages
library(tidyverse)
library(caret)
library(tree)
library(rpart)
library(rpart.plot)
library(e1071)