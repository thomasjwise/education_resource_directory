##### Beginners Worksheet ######################################################

## Package and Data Loading

library(tidyverse)
library(caret)
library(tree)
library(rpart)
library(rpart.plot)
library(e1071)

options(scipen = 999)

winequality_red <- read_csv("data/winequality-red.csv")


##### Section 1: Data Preparation for Tree-based Models ########################

## Exercise 1: Transform the data: Numeric to Binary

winequality_red$quality_bin <- ifelse(winequality_red$quality <= 6, 
                                      yes = "low", no = "high")

winequality_red$quality_bin <- factor(winequality_red$quality_bin)


## Exercise 2: Prepare the data yourself


### Set the seed 
set.seed(13052006)


#### Use summary() to look at the descriptive statistics for both groups! 




##### Section 2: My First Decision Tree ########################################

## Exercise 3: Using `rpart()`, with the formula listed below, generate a classification tree to predict quality

## formula = quality_bin ~ alcohol + citric acid + pH


## Exercise 4: Using `rpart()`, generate a regression tree to predict quality.


## Exercise 5: Compare the plots side by side, which do you think will more accuracy predict red wine quality, the classification or regression tree?



##### Section 3: Evaluating Tree-based Models ##################################

## Exercise 6: Using the `predict()` function, apply both the classification and regression trees to the testing data.

## For classification trees 

## For classification trees 



## Convert the predicted information to a dataframe


## For each row in in the predicted class, if the probability is greater for high than low, then list high as the predicted. 
for(i in 1:nrow(class_pred)){
  if(class_pred[i,1] > class_pred[i,2]){
    class_pred[i,"pred"] <- "high"
  } else {
    class_pred[i,"pred"] <- "low"
  }
}

## Convert to a factor
class_pred$pred <- factor(class_pred$pred)

## Exercise 7: After manipulating the predicted class data as above, use the function `confusionMatrix()` to evaluate this model


## Exercise 8: Using the function `RMSE()` evaluate the regression tree model


##### Section 4: Review & Comparison ###########################################

## Exercise 9: Using all the knowledge from today's session, 
## and that available from the *Learning Materials* tab, 
## run additional regression and classification trees, 
## using as much or as little of the data set provided as you wish, 
## and compare which combination of variables is best at predicting quality.
