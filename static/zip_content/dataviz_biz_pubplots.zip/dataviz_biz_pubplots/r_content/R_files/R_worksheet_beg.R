## Beginners Worksheet Short Form ==============================================

## Package 

library(tidyverse)
library(RColorBrewer)
library(ggpubr)

## Scienfic Notation 
options(scipen = 999)

## Data Loading and Adjustment
WDB_1999 <- read_csv("data/WDB_1999.csv")
WDB_1999$Continent <- factor(WDB_1999$Continent)


## Section 1: Specifying the visual space  =====================================

  ## Exercise 1: Using the example code provided, 
      ## Add two of the discussed themes individually
      ## How are these themes different? 
      ## Under what situations would one be better than another?
    
  ggplot() + 
    geom_point(data = WDB_1999, 
               mapping = aes(x = lifeexp.ma, 
                             y = lifeexp.fe, 
                             colour = Continent))

  ## Exercise 2: Using your preferred theme function from exercise 1. 
      ## Add another theme layer (theme()), specifying a novel background colour
      ## You can use the template provided, replacing "XXX" with a colour of your choice.

  ggplot() + 
    geom_point(data = WDB_1999, 
               mapping = aes(x = lifeexp.ma, 
                             y = lifeexp.fe, 
                             colour = Continent)) + 
    theme_minimal() + 
    theme(plot.background = element_rect("blue"))
  
  ## Exercise 3: Going further, run the command "?theme" 
      ## When doing so, explore the large range of potential adaptions. 
      ## Spend some time deploying these to understand these adaptions. 
  
      ## HINT: Remember to follow the instructions provided relating to: 
          ## element_text(), element_rect(), element_line() etc
  
  ?theme
  
  ggplot() + 
    geom_point(data = WDB_1999, 
               mapping = aes(x = lifeexp.ma, 
                             y = lifeexp.fe, 
                             colour = Continent)) + 
    theme_minimal() + 
    theme()

## Section 2: Specifying the axis's  ===========================================
  
  ## Exercise 4: Rather than using theme, increase the limits of the x & y axis
      ## HINT: Use lims(y = c(), x = c()).
      ## Placing limits at 0 & 100. 
  
  ggplot() + 
    geom_point(data = WDB_1999, 
               mapping = aes(x = lifeexp.ma, 
                             y = lifeexp.fe, 
                             colour = Continent)) + 
    theme_minimal() + 
    lims(y = c(,), x = c(,))
  
  
  ## Exercise 5: Currently the produced graph breaks the axis scale every 25 years
      ## Using the example provided, use scale_y_continuous & scale_x_continuous
      ## To specify both limits and specific breaks (every 20) in the axis
      ## You can use, n.breaks or breaks to specify the breaks 
  
  ggplot() + 
    geom_point(data = WDB_1999, 
               mapping = aes(x = lifeexp.ma, 
                             y = lifeexp.fe, 
                             colour = Continent)) + 
    theme_minimal() + 
    scale_x_continuous() +
    scale_y_continuous()
  
  
  ## Exercise 6: Using the code generated in Exercise 5
    ## Add in specification of the angle of break labels using 
    ## axis.text.x and axis.text.y respectively. 
    ## Ensure to add these in a theme() layer
  
  ggplot() + 
    geom_point(data = WDB_1999, 
               mapping = aes(x = lifeexp.ma, 
                             y = lifeexp.fe, 
                             colour = Continent)) + 
    theme_minimal() +
    theme(,)
  
  ## Exercise 7: Now considering the relationship between population and life expentancy 
      ## Plot these two variables using a scatter plot, using a log10 scale for population
  
  ggplot() + 
    geom_point(data = WDB_1999, 
               mapping = aes(x = Pop,
                             y = lifeexp, 
                             colour = Continent)) + 
    theme_minimal() 
  
## Section 3: Specifying Labels  ===============================================  
  
  ## Exercise 8: Using the layer definition labs(), generate names for the x, y and title
      ## For the plot in exercise 7
  
  
  ## Exercise 9: Using the plot generated in Exercise 8, indicate the nation with the lowest life expentancy
      ## Add an annotation, labelling "Sierra Leone" at x = 1000000, y = 42
  
  ## Exercise 10: Add two reference lines (indicating the UK) in life expentancy and Population,
      ## Build this upon exercise 9, and use x & y intercept points as x = 58682466, y = 77.39024
  
  
## Section 4: Specifying Layouts ===============================================
  
  ## Exercise 11: Using facet_grid(), generate a matrix of panels for the multiple continents 
      ## Build this upon Exercise 10
      ## Consider the issue(s) with using this facet style?
  
  ## Exercise 12: Generate the following plots, assigning each to a relevant variable name (plot_1 : plot_4)
      ## Using ggarrange, combine these four plots into one visualisation
      ## 
  
      ## plot_1 -> Scatter plot, between Male Population & Male Life expentancy 
      ## plot_2 -> Scatter plot, between Female Population & Female life expentancy
      ## plot_3 -> Scatter plot, between Overall Population & Overall Life expentancy 
      ## plot_4 -> Scatter plot, birthrate & deathrate 
    
      ## For each ensure to set colour as continent, and that they share a common legend 
        ## Set common.legend = TRUE
  
      ## Throughout, use all your knowledge adding information wherever required

  
  
  

  

  
  